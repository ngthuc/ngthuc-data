module Bourbon
  VERSION = "4.2.4"
end
